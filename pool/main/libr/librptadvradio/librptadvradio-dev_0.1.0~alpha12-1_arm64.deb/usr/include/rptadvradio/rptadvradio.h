/**
 * @file rptadvradio.h
 * @brief ABI 5 for one prepared, portable 48 kHz radio session.
 *
 * The shared object owns radio DSP and signaling state. Device, Asterisk,
 * FFmpeg, RNNoise, and elastic-ring implementations remain in independently
 * versioned adapters and are supplied as narrowly typed borrowed ports.
 */
#ifndef RPTADV_RADIO_H
#define RPTADV_RADIO_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

#define RPTADV_RADIO_ABI_VERSION 5U /**< Breaking whole-session ABI. */
/** Speech qualification mode: unchanged receive policy. */
#define RPTADV_RADIO_VAD_OFF 0U
/** Speech qualification mode: first speech latches the RF burst. */
#define RPTADV_RADIO_VAD_KERCHUNK 1U
/** Speech qualification mode: speech plus its configured hang. */
#define RPTADV_RADIO_VAD_ON 2U
/** Minimum active speech lookback at the native 48 kHz rate. */
#define RPTADV_RADIO_VAD_PREROLL_FRAMES 7680U
/** Minimum active speech lookback in milliseconds. */
#define RPTADV_RADIO_VAD_PREROLL_MS 160U

#define RPTADV_RADIO_NATIVE_SAMPLE_RATE_HZ 48000U /**< Immutable native rate. */
#define RPTADV_RADIO_CANONICAL_CHANNELS 2U /**< Interleaved device channels. */
#define RPTADV_RADIO_CTCSS_TONE_COUNT 38U /**< CTCSS mapping-table length. */
#define RPTADV_RADIO_CTCSS_CALIBRATION_TARGET (2400.0F / 32768.0F) /**< Normalized RX decoder target. */

/** @brief Opaque runtime generation owned by the shared object. */
struct rptadv_radio_session;
/** @brief Control-owned candidate storage for one pair of owner updates. */
struct rptadv_radio_session_update;

/** @brief Result from one session operation. */
enum rptadv_radio_result {
  RPTADV_RADIO_OK = 0, /**< Operation completed. */
  RPTADV_RADIO_INVALID_ARGUMENT = -1, /**< An argument is invalid. */
  RPTADV_RADIO_PROVIDER_FAILED = -2, /**< A borrowed port failed. */
  RPTADV_RADIO_FRAME_COUNT_EXCEEDED = -3, /**< Callback exceeds setup bound. */
  RPTADV_RADIO_UNSUPPORTED = -4, /**< Stream rate or layout is unsupported. */
  RPTADV_RADIO_NOT_READY = -5, /**< Session has not been warmed. */
  RPTADV_RADIO_BUSY = -6, /**< A serial callback has two callers. */
};

/** @brief Receive carrier-indication source. */
enum rptadv_radio_carrier_source {
  RPTADV_RADIO_CARRIER_DISABLED = 0, /**< No carrier source. */
  RPTADV_RADIO_CARRIER_DSP = 1, /**< Discriminator-noise detector. */
  RPTADV_RADIO_CARRIER_VOX = 2, /**< Audio-level detector. */
  RPTADV_RADIO_CARRIER_USB = 3, /**< Normal USB GPIO. */
  RPTADV_RADIO_CARRIER_USB_INVERTED = 4, /**< Inverted USB GPIO. */
  RPTADV_RADIO_CARRIER_PARALLEL = 5, /**< Normal parallel input. */
  RPTADV_RADIO_CARRIER_PARALLEL_INVERTED = 6, /**< Inverted parallel input. */
  RPTADV_RADIO_CARRIER_EXTERNAL = 7, /**< Independent normalized COR; validity required. */
  RPTADV_RADIO_CARRIER_OPEN = 8, /**< Always-open carrier; tone qualification still applies. */
};

/** @brief Native discriminator-noise detector response. */
enum rptadv_radio_noise_filter_profile {
  RPTADV_RADIO_NOISE_FILTER_STANDARD = 0, /**< Established default response. */
  RPTADV_RADIO_NOISE_FILTER_ALTERNATE = 1, /**< Alternate established response. */
};

/** @brief Receive subaudible-indication source. */
enum rptadv_radio_subaudible_source {
  RPTADV_RADIO_SUBAUDIBLE_DISABLED = 0, /**< No required indication. */
  RPTADV_RADIO_SUBAUDIBLE_USB = 1, /**< Normal USB GPIO. */
  RPTADV_RADIO_SUBAUDIBLE_USB_INVERTED = 2, /**< Inverted USB GPIO. */
  RPTADV_RADIO_SUBAUDIBLE_DSP = 3, /**< Native CTCSS or DCS decoder. */
  RPTADV_RADIO_SUBAUDIBLE_PARALLEL = 4, /**< Normal parallel input. */
  RPTADV_RADIO_SUBAUDIBLE_PARALLEL_INVERTED = 5, /**< Inverted parallel input. */
};

/** @brief Transmit CTCSS/DCS turn-off policy. */
enum rptadv_radio_tone_off_mode {
  RPTADV_RADIO_TONE_OFF_NONE = 0, /**< Release normally. */
  RPTADV_RADIO_TONE_OFF_PHASE_SHIFT = 1, /**< Reverse burst. */
  RPTADV_RADIO_TONE_OFF_TONE_REMOVE = 2, /**< Remove tone before PTT. */
  RPTADV_RADIO_TONE_OFF_TAIL_TONE = 3, /**< Send configured tail tone. */
};

/** @brief One hardware output assignment. */
enum rptadv_radio_output_route {
  RPTADV_RADIO_OUTPUT_DISABLED = 0, /**< Silence. */
  RPTADV_RADIO_OUTPUT_VOICE = 1, /**< Program audio. */
  RPTADV_RADIO_OUTPUT_TONE = 2, /**< CTCSS/DCS only. */
  RPTADV_RADIO_OUTPUT_COMPOSITE = 3, /**< Program plus CTCSS/DCS. */
  RPTADV_RADIO_OUTPUT_AUXILIARY_VOICE = 4, /**< Auxiliary program route. */
};

/** @brief Current transmitter-signaling phase. */
enum rptadv_radio_transmitter_state {
  RPTADV_RADIO_TRANSMITTER_IDLE = 0, /**< No transmit request is active. */
  RPTADV_RADIO_TRANSMITTER_ACTIVE = 1, /**< Normal program transmission. */
  RPTADV_RADIO_TRANSMITTER_TONE_OFF = 2, /**< CTCSS or DCS turn-off phase. */
  RPTADV_RADIO_TRANSMITTER_FINISHING = 4, /**< Final drain before release. */
  RPTADV_RADIO_TRANSMITTER_COMPLETE = 5, /**< Release transition completed. */
};

/** @brief Owner-ordered event kinds. */
enum rptadv_radio_event_kind {
  RPTADV_RADIO_EVENT_NONE = 0, /**< No event. */
  RPTADV_RADIO_EVENT_CARRIER = 1, /**< Carrier edge. */
  RPTADV_RADIO_EVENT_SUBAUDIBLE = 2, /**< CTCSS/DCS qualification edge. */
  RPTADV_RADIO_EVENT_RECEIVER_KEYED = 3, /**< Qualified receiver edge. */
  RPTADV_RADIO_EVENT_CTCSS_DECODE = 4, /**< Decoded CTCSS index changed. */
  RPTADV_RADIO_EVENT_DCS_DECODE = 5, /**< DCS validity changed. */
  RPTADV_RADIO_EVENT_PTT = 6, /**< Logical PTT edge. */
  RPTADV_RADIO_EVENT_CTCSS_TRANSMIT = 7, /**< Transmit tone changed. */
  RPTADV_RADIO_EVENT_RECEIVER_BLANKING = 8, /**< RX blanking armed. */
  RPTADV_RADIO_EVENT_PROVIDER_FAILURE = 9, /**< External port failed. */
};

/** @brief Process one exact mono F32 span without allocation or blocking. */
typedef int32_t (*rptadv_radio_process_f32_fn)(void *context,
                                               const float *input,
                                               float *output,
                                               uint32_t frame_count);
/** @brief Exercise a prepared object without publishing live output. */
typedef int32_t (*rptadv_radio_warm_fn)(void *context, uint32_t frame_count);
/** @brief Advance a prepared bypass path without producing PCM. */
typedef int32_t (*rptadv_radio_bypass_fn)(void *context,
                                         uint32_t frame_count);

/** @brief Latest diagnostics returned by a rate-adjusting ring provider. */
struct rptadv_radio_ring_observation {
  uint32_t occupancy_frames; /**< PCM frames retained. */
  uint32_t reserve_frames; /**< Protected minimum occupancy. */
  uint32_t target_frames; /**< Occupancy servo target. */
  uint32_t capacity_frames; /**< Allocated capacity. */
  double ratio; /**< Current input-to-output ratio. */
  uint64_t underrun_samples; /**< Cumulative absent output. */
  uint64_t overrun_samples; /**< Cumulative discarded input. */
  uint64_t concealment_samples; /**< Cumulative concealment output. */
};

/** @brief Program-ring diagnostics and sample-associated RX qualification. */
struct rptadv_radio_program_ring_result {
  struct rptadv_radio_ring_observation observation; /**< Ring diagnostics. */
  uint32_t receiver_keyed; /**< Rendered span contains qualified local RX. */
  int32_t ctcss_decoded_index; /**< Aligned CTCSS table index or negative. */
  uint32_t dcs_valid; /**< Aligned configured DCS state. */
};

/** @brief Render exact mono F32 from the prepared program ring. */
typedef int32_t (*rptadv_radio_ring_render_f32_fn)(
    void *context, float *output, uint32_t frame_count,
    struct rptadv_radio_program_ring_result *result);

/** @brief Borrowed prepared processor; null callbacks make it a bypass. */
struct rptadv_radio_processor_port {
  void *context; /**< Provider state valid through session destruction. */
  rptadv_radio_process_f32_fn process_f32; /**< Exact-frame callback. */
  rptadv_radio_bypass_fn bypass; /**< Advance disabled/bypassed state. */
  rptadv_radio_warm_fn warm; /**< Setup warm-up callback. */
};

/** @brief Borrowed program-ring consumer; null render produces silence. */
struct rptadv_radio_program_ring_port {
  void *context; /**< Provider state valid through session destruction. */
  rptadv_radio_ring_render_f32_fn render_f32; /**< Exact-frame render. */
  rptadv_radio_warm_fn warm; /**< Non-consuming setup warm-up. */
};

/** @brief Immutable discriminator and subaudible detector policy. */
struct rptadv_radio_receive_config {
  uint32_t noise_filter_profile; /**< enum rptadv_radio_noise_filter_profile. */
  uint32_t squelch_open_level; /**< MICOR opening threshold. */
  uint32_t squelch_hysteresis; /**< MICOR closing hysteresis. */
  float ctcss_decoder_gain; /**< Linear decoder-only input gain. */
  int32_t vox_threshold; /**< VOX threshold, 0 through 32767 PCM codes. */
  int32_t vox_hang_ms; /**< VOX hang, 0 through 32767 milliseconds. */
  uint32_t ctcss_enabled; /**< Enable native CTCSS decode. */
  uint64_t ctcss_tone_mask; /**< Enabled CTCSS table entries. */
  uint32_t ctcss_relax; /**< Select relaxed decoder tolerance. */
  uint32_t dcs_enabled; /**< Enable native DCS decode. */
  int32_t dcs_code; /**< Three-octal-digit DCS code. */
  uint32_t dcs_inverted; /**< Invert receive DCS polarity. */
  uint32_t cpu_saver_enabled; /**< Freeze idle voice/calibration work. */
  uint32_t native_squelch_delay_frames; /**< Native audible delay; active internal VAD enforces its minimum. */
  uint32_t vad_mode; /**< 0 Off, 1 first-speech Kerchunk, 2 speech plus hang. */
  uint32_t vad_hang_ms; /**< Native-clock speech hang; default 1000 ms. */
  uint32_t vad_external_delay; /**< 0 reuse internal delay, 1 controller-owned delay. */
};

/** @brief Immutable receiver qualification and duplex policy. */
struct rptadv_radio_qualification_config {
  uint32_t carrier_source; /**< enum rptadv_radio_carrier_source. */
  uint32_t subaudible_source; /**< enum rptadv_radio_subaudible_source. */
  uint32_t subaudible_override; /**< Admit carrier without tone. */
  uint32_t advanced_transport; /**< Advanced full-rate transport active. */
  uint32_t radio_duplex; /**< Permit receive during transmit. */
  uint32_t rx_on_delay_blocks; /**< Required 20 ms admission blocks. */
  uint32_t tx_off_delay_blocks; /**< Post-transmit 20 ms guard blocks. */
};

/** @brief Immutable transmitter signaling, level, and routing. */
struct rptadv_radio_transmit_config {
  uint32_t ctcss_transmit_enabled; /**< Enable transmit CTCSS selection. */
  int32_t default_ctcss_frequency_tenths_hz; /**< Default transmit tone. */
  int32_t mapped_ctcss_frequency_tenths_hz[RPTADV_RADIO_CTCSS_TONE_COUNT]; /**< RX tone map. */
  uint32_t tone_off_mode; /**< enum rptadv_radio_tone_off_mode. */
  int32_t ctcss_turnoff_duration_ms; /**< CTCSS tail duration. */
  double ctcss_turnoff_phase_shift_degrees; /**< Reverse-burst phase. */
  double ctcss_turnoff_tail_tone_hz; /**< Replacement tail tone. */
  uint32_t dcs_transmit_enabled; /**< Enable transmit DCS. */
  uint32_t dcs_turnoff_enabled; /**< Enable DCS turn-off. */
  int32_t dcs_turnoff_duration_ms; /**< DCS turn-off duration. */
  int32_t receiver_blanking_ms; /**< Post-PTT receive blanking. */
  int32_t tx_settle_time_ms; /**< Audio delay after physical PTT. */
  uint32_t cpu_saver_enabled; /**< Halt idle signaling work. */
  int32_t dcs_code; /**< Transmit DCS code. */
  uint32_t dcs_inverted; /**< Invert transmit DCS polarity. */
  float dcs_peak; /**< Normalized DCS peak. */
  float ctcss_peak; /**< Normalized CTCSS oscillator peak. */
  uint32_t output_a_route; /**< enum rptadv_radio_output_route. */
  uint32_t output_b_route; /**< enum rptadv_radio_output_route. */
  float output_a_tone_gain; /**< Output A tone calibration. */
  float output_a_tone_bias; /**< Output A tone bias. */
  float output_b_tone_gain; /**< Output B tone calibration. */
  float output_b_tone_bias; /**< Output B tone bias. */
};

/** @brief Complete immutable setup for one runtime generation. */
struct rptadv_radio_session_config {
  uint32_t struct_size; /**< Size supplied by caller. */
  uint32_t abi_version; /**< Must equal RPTADV_RADIO_ABI_VERSION. */
  uint64_t generation_id; /**< Tag copied to observations. */
  uint32_t native_sample_rate_hz; /**< Must be 48000. */
  uint32_t interleaved_channels; /**< Must be two. */
  uint32_t maximum_receive_frame_count; /**< Preallocated RX bound. */
  uint32_t maximum_transmit_frame_count; /**< Preallocated TX bound. */
  uint32_t publication_interval_ms; /**< Periodic status cadence. */
  uint32_t receive_channel; /**< Capture channel, zero or one. */
  float receive_input_gain; /**< Linear post-deemphasis gain. */
  struct rptadv_radio_receive_config receive; /**< Detector policy. */
  struct rptadv_radio_qualification_config qualification; /**< RX gating. */
  struct rptadv_radio_transmit_config transmit; /**< TX policy. */
};

/**
 * @brief Borrowed prepared runtime ports grouped by exact pipeline role.
 *
 * Receive order is deemphasis, squelch gate/input gain, fixed filter graph,
 * the prepared decoded-tone or 55 Hz tail notch, RNNoise, then dynamics.
 * Transmit processing precedes native CTCSS/DCS mix. Providers must be
 * allocation-free, lock-free, nonblocking, and exact-frame.
 */
struct rptadv_radio_session_ports {
  uint32_t struct_size; /**< Size supplied by caller. */
  struct rptadv_radio_processor_port receive_deemphasis; /**< RX deemphasis. */
  struct rptadv_radio_processor_port receive_filter; /**< Fixed RX filtering. */
  struct rptadv_radio_processor_port
      receive_ctcss_notch[RPTADV_RADIO_CTCSS_TONE_COUNT]; /**< Prepared one-tone notches. */
  struct rptadv_radio_processor_port receive_noise_reduction; /**< RNNoise. */
  struct rptadv_radio_processor_port receive_dynamics; /**< RX dynamics. */
  struct rptadv_radio_processor_port transmit_program; /**< Final TX graph. */
  struct rptadv_radio_processor_port transmit_dcs_normal_filter; /**< Normal DCS NRZ shaper. */
  struct rptadv_radio_processor_port transmit_dcs_turnoff_filter; /**< DCS turn-off sine shaper. */
  struct rptadv_radio_program_ring_port program_ring; /**< TX program source. */
  struct rptadv_radio_processor_port receive_ctcss_tail_notch; /**< Prepared 55 Hz tail notch. */
};

/** @brief Flags carried by receive_input.subaudible_override. */
enum rptadv_radio_receive_flags {
  RPTADV_RADIO_RECEIVE_TONE_OVERRIDE = 1, /**< Admit carrier without decoded tone. */
  RPTADV_RADIO_RECEIVE_EXTERNAL_COR_VALID = 2, /**< Independent COR snapshot is fresh. */
  RPTADV_RADIO_RECEIVE_EXTERNAL_COR_PRESENT = 4 /**< Independent COR is asserted. */
};
/** @brief Hardware snapshots supplied to one receive callback. */
struct rptadv_radio_receive_input {
  uint32_t hardware_carrier; /**< Normal GPIO COR. */
  uint32_t parallel_carrier; /**< Normal parallel COR. */
  uint32_t hardware_subaudible; /**< Normal GPIO tone input. */
  uint32_t parallel_subaudible; /**< Normal parallel tone input. */
  uint32_t subaudible_override; /**< rptadv_radio_receive_flags; unknown bits rejected.
    External COR is independent of GPIO and tone. A missing valid bit closes
    CARRIER_EXTERNAL even with tone override, without USB/DSP fallback. */
};

/** @brief Control/hardware snapshots supplied to one transmit callback. */
struct rptadv_radio_transmit_input {
  uint32_t external_ptt_request; /**< Program requests transmit. */
  uint32_t physical_ptt_applied; /**< Hardware reports keyed. */
  uint32_t render_admitted; /**< A DAC span will be delivered. */
  uint32_t ctcss_inhibit; /**< Suppress selected transmit CTCSS. */
  uint32_t calibrated_test_tone; /**< Replace program with 1 kHz reference. */
  int32_t forced_ctcss_tenths_hz; /**< Forced tone, or zero for normal selection. */
};

/** @brief Immediate observation from one receive callback. */
struct rptadv_radio_receive_result {
  uint64_t generation_id; /**< Runtime generation tag. */
  uint64_t first_sample_index; /**< First RX stream sample. */
  uint32_t frame_count; /**< Consumed native frames. */
  uint32_t carrier_active; /**< Resolved carrier state. */
  uint32_t subaudible_active; /**< Resolved tone state. */
  uint32_t receiver_keyed; /**< Qualified receiver state. */
  int32_t ctcss_decoded_index; /**< Table index or negative. */
  uint32_t dcs_valid; /**< Configured DCS is decoded. */
  int16_t rssi_peak; /**< Compatibility RSSI value. */
  uint32_t rssi_updated; /**< RSSI window completed. */
  float ctcss_decoder_peak; /**< Normalized post-gain CTCSS half peak-to-peak. */
  float input_peak; /**< Raw selected-channel normalized peak. */
  float input_rms; /**< Raw selected-channel normalized RMS. */
  uint64_t input_rail_samples; /**< Raw samples at a hardware rail. */
  float output_peak; /**< Processed normalized peak. */
  float output_rms; /**< Processed normalized RMS. */
  uint64_t output_rail_samples; /**< Processed samples at a hardware rail. */
  uint32_t periodic_status_due; /**< Publication deadline crossed. */
  uint32_t raw_receiver_keyed; /**< RF qualification before speech admission. */
  uint64_t rf_burst_id; /**< Receive-owner burst identity; zero/untracked when Off. */
  uint32_t vad_mode; /**< Effective speech mode; Kerchunk may normalize to On. */
  uint32_t vad_voice_active; /**< Most recent fresh speech decision. */
  float vad_score; /**< Most recent Earshot probability, zero when unavailable. */
  uint64_t vad_voice_sample_index; /**< Last fresh voice native position, UINT64_MAX if absent. */
  uint32_t vad_preroll_frames; /**< Required native delay reserve; zero when Off. */
};

/** @brief Immediate observation from one transmit callback. */
struct rptadv_radio_transmit_result {
  uint64_t generation_id; /**< Runtime generation tag. */
  uint64_t first_sample_index; /**< First TX stream sample. */
  uint32_t frame_count; /**< Produced native frames. */
  uint32_t logical_ptt; /**< Current PTT intent. */
  int32_t transmitter_state; /**< enum rptadv_radio_transmitter_state. */
  int32_t selected_ctcss_tenths_hz; /**< Selected tone. */
  float program_peak; /**< Post-graph mono program peak. */
  float program_rms; /**< Post-graph mono program RMS. */
  uint64_t program_rail_samples; /**< Post-graph program rail samples. */
  float output_peak; /**< Routed stereo normalized peak. */
  float output_rms; /**< Routed stereo normalized RMS. */
  uint64_t output_rail_samples; /**< Routed stereo rail samples. */
  uint32_t periodic_status_due; /**< Publication deadline crossed. */
  struct rptadv_radio_ring_observation program_ring; /**< Ring diagnostics. */
};

/** @brief One owner-ordered, generation-tagged edge. */
struct rptadv_radio_event {
  uint64_t generation_id; /**< Runtime generation tag. */
  uint64_t sample_index; /**< Owner stream position after detection. */
  uint32_t kind; /**< enum rptadv_radio_event_kind. */
  int32_t value; /**< New state or selected value. */
};

/** @brief Lock-free latest-value session diagnostics. */
struct rptadv_radio_snapshot {
  uint64_t generation_id; /**< Runtime generation tag. */
  uint64_t receive_frames; /**< Cumulative RX frames. */
  uint64_t transmit_frames; /**< Cumulative TX frames. */
  float receive_input_peak; /**< Latest raw selected-channel RX peak. */
  float receive_input_rms; /**< Latest raw selected-channel RX RMS. */
  float receive_ctcss_decoder_peak; /**< Latest normalized CTCSS decoder peak. */
  float receive_output_peak; /**< Latest processed RX peak. */
  float receive_output_rms; /**< Latest processed RX RMS. */
  float transmit_program_peak; /**< Latest post-graph program peak. */
  float transmit_program_rms; /**< Latest post-graph program RMS. */
  float transmit_output_peak; /**< Latest routed stereo TX peak. */
  float transmit_output_rms; /**< Latest routed stereo TX RMS. */
  uint64_t receive_input_rail_samples; /**< Cumulative raw RX rail samples. */
  uint64_t receive_output_rail_samples; /**< Cumulative processed RX rails. */
  uint64_t transmit_program_rail_samples; /**< Cumulative program rails. */
  uint64_t transmit_output_rail_samples; /**< Cumulative output rails. */
  uint64_t provider_failures; /**< External callback failures. */
  uint64_t receive_event_drops; /**< Full RX queue events. */
  uint64_t transmit_event_drops; /**< Full TX queue events. */
  uint32_t carrier_active; /**< Latest carrier state. */
  uint32_t subaudible_active; /**< Latest tone state. */
  uint32_t receiver_keyed; /**< Latest receiver state. */
  uint32_t logical_ptt; /**< Latest PTT intent. */
  int32_t ctcss_decoded_index; /**< Latest CTCSS index. */
  uint32_t dcs_valid; /**< Latest DCS state. */
  struct rptadv_radio_ring_observation program_ring; /**< Ring diagnostics. */
  uint32_t raw_receiver_keyed; /**< RF qualification before speech admission. */
  uint64_t rf_burst_id; /**< Receive-owner burst identity; zero/untracked when Off. */
  uint32_t vad_mode; /**< Effective speech mode; Kerchunk may normalize to On. */
  uint32_t vad_voice_active; /**< Most recent fresh speech decision. */
  float vad_score; /**< Most recent Earshot probability, zero when unavailable. */
  uint64_t vad_voice_sample_index; /**< Last fresh voice native position, UINT64_MAX if absent. */
  uint32_t vad_preroll_frames; /**< Required native delay reserve; zero when Off. */
};

/** @brief Independent encoder/decoder assignment. */
enum rptadv_radio_ctcss_source {
  RPTADV_RADIO_CTCSS_DISABLED = 0, /**< No CTCSS for this direction. */
  RPTADV_RADIO_CTCSS_DSP = 1, /**< Native detector or generator. */
  RPTADV_RADIO_CTCSS_EXTERNAL = 2 /**< Normalized hardware input/output. */
};

/** @brief Copied immutable profile; changes require stopped-session replacement. */
struct rptadv_radio_profile {
  uint32_t struct_size; /**< Size of this record. */
  uint32_t kind; /**< 0 native audio, 1 appliance direct codec. */
  uint32_t carrier_source; /**< 0 normalized hardware COR, 1 DSP noise. */
  uint32_t ctcss_encode_source; /**< enum rptadv_radio_ctcss_source. */
  uint32_t ctcss_decode_source; /**< enum rptadv_radio_ctcss_source. */
};

/** @brief Actual backend facilities, each 0 or 1; not requested features. */
struct rptadv_radio_profile_capabilities {
  uint32_t struct_size; /**< Size of this record. */
  uint32_t hardware_cor; /**< Normalized COR available. */
  uint32_t external_ctcss_decode; /**< Decoder indication available. */
  uint32_t external_ctcss_encode; /**< Encoder-enable output available. */
  uint32_t dsp_tone_audio; /**< Audio path can carry native signaling. */
};

/** @brief Normalized snapshots for profiled receive; no hardware I/O occurs. */
struct rptadv_radio_profile_receive_input {
  uint32_t struct_size; /**< Size of this record. */
  struct rptadv_radio_receive_input controls; /**< Remaining control policy. */
  uint32_t hardware_cor; /**< Normalized COR, 0 or 1. */
  uint32_t hardware_cor_valid; /**< COR snapshot valid, 0 or 1. */
  uint32_t external_ctcss; /**< Raw normalized decoder indication, 0 or 1. */
  uint32_t external_ctcss_valid; /**< Decoder snapshot valid, 0 or 1. */
};

/** @brief Exact receive result and independent external-decoder observation. */
struct rptadv_radio_profile_receive_result {
  uint32_t struct_size; /**< Caller sets available size before every call. */
  struct rptadv_radio_receive_result result; /**< Existing receive diagnostics. */
  uint32_t external_ctcss; /**< Decoder value even when not selected. */
  uint32_t external_ctcss_valid; /**< Whether that observation is valid. */
};

/** @brief Logical requests still subject to hardware admission/interlock. */
struct rptadv_radio_prepared_outputs {
  uint32_t logical_ptt; /**< PTT requested at this callback boundary. */
  uint32_t external_ctcss_enable; /**< External encoder only; never without PTT. */
};

/** @brief PCM diagnostics and prepared actions from the same serial TX call. */
struct rptadv_radio_profile_transmit_result {
  uint32_t struct_size; /**< Caller sets available size before every call. */
  struct rptadv_radio_transmit_result result; /**< Existing TX diagnostics. */
  struct rptadv_radio_prepared_outputs outputs; /**< Released on errors. */
};

/** @brief Opaque, serially owned prepared speech classifier. */
struct rptadv_speech_analysis;

/** @brief Per-source classification; no programme retention or hangtime. */
struct rptadv_speech_analysis_config {
  uint32_t struct_size; /**< Caller-provided readable size. */
  uint32_t source_rate_hz; /**< Fixed mono source rate, 8000..192000 Hz. */
  uint32_t maximum_source_frames; /**< Maximum nonempty span, 1..4096 frames. */
  float speech_threshold; /**< Finite inclusive score threshold, 0..1. */
  uint32_t speech_onset_frames; /**< Positive consecutive 16-ms analysis frames. */
};

/** @brief Shared classifier output on the input source sample clock. */
struct rptadv_speech_analysis_result {
  uint32_t struct_size; /**< Caller sets writable size before every call. */
  uint32_t voice_active; /**< Latest complete frame satisfies configured onset. */
  float score; /**< Latest probability; zero before a complete frame. */
  uint32_t reserved; /**< Always zero. */
  uint64_t last_voice_source_sample; /**< Last positive position; UINT64_MAX if none. */
};

/** @brief Immutable whole-session ABI 5 function table. */
struct rptadv_radio_descriptor {
  uint32_t struct_size; /**< Descriptor size. */
  uint32_t abi_version; /**< Descriptor ABI. */
  const char *capability_name; /**< Stable capability name. */
  enum rptadv_radio_result (*session_create)(
      const struct rptadv_radio_session_config *,
      const struct rptadv_radio_session_ports *,
      struct rptadv_radio_session **); /**< Prepare a generation. */
  enum rptadv_radio_result (*session_warm)(
      struct rptadv_radio_session *); /**< Warm processors before start. */
  enum rptadv_radio_result (*session_receive)(
      struct rptadv_radio_session *, const float *, float *, uint32_t,
      const struct rptadv_radio_receive_input *,
      struct rptadv_radio_receive_result *); /**< Exact RX callback. */
  enum rptadv_radio_result (*session_transmit)(
      struct rptadv_radio_session *, float *, uint32_t,
      const struct rptadv_radio_transmit_input *,
      struct rptadv_radio_transmit_result *); /**< Exact TX callback. */
  enum rptadv_radio_result (*session_snapshot)(
      const struct rptadv_radio_session *,
      struct rptadv_radio_snapshot *); /**< Read lock-free status. */
  uint32_t (*session_pop_receive_event)(
      const struct rptadv_radio_session *,
      struct rptadv_radio_event *); /**< Pop one RX event. */
  uint32_t (*session_pop_transmit_event)(
      const struct rptadv_radio_session *,
      struct rptadv_radio_event *); /**< Pop one TX event. */
  void (*session_destroy)(struct rptadv_radio_session *); /**< Destroy stopped session. */
  /** Prepare internal storage only: never call borrowed ports. New processors
   * must be warmed by their owner before publication; reused live ports must
   * not be warmed again. program_ring must be empty and cannot be replaced. */
  enum rptadv_radio_result (*session_prepare_update)(
      const struct rptadv_radio_session_config *,
      const struct rptadv_radio_session_ports *,
      struct rptadv_radio_session_update **);
  /** Apply once between receive calls, on that serial owner only. Preserve
   * unchanged detector history, qualification, delay contents and sample clock.
   * Both frame maxima must match the live session; failure changes nothing.
   * The live generation id remains fixed; the publication interval may change.
   * No allocation, reclamation, provider call or waiting occurs during apply. */
  enum rptadv_radio_result (*session_apply_receive_update)(
      struct rptadv_radio_session *, struct rptadv_radio_session_update *);
  /** Apply once between transmit calls, on that serial owner only. Preserve
   * PTT, signaling timers, oscillators and the program ring. May run concurrently
   * with receive update. Borrowed ports must outlive their last live callback. */
  enum rptadv_radio_result (*session_apply_transmit_update)(
      struct rptadv_radio_session *, struct rptadv_radio_session_update *);
  /** Reclaim unused/displaced internal storage on the control plane, after
   * both callback owners acknowledge or an unpublished update is cancelled.
   * Never destroys borrowed processors; their owner manages their lifetime. */
  void (*session_destroy_update)(struct rptadv_radio_session_update *);
  /** Copy and validate independent source selections before allocating.
   * Config DSP enable fields must agree with DSP selection. External encode
   * rejects native frequency, level and waveform settings. Port lifetimes and
   * warm-up requirements are the same as session_create. */
  enum rptadv_radio_result (*session_create_profiled)(
      const struct rptadv_radio_session_config *, const struct rptadv_radio_session_ports *,
      const struct rptadv_radio_profile *, const struct rptadv_radio_profile_capabilities *,
      struct rptadv_radio_session **);
  /** Prepare only same-profile/capability updates; existing apply/destroy
   * operations own publication and reclamation. No live provider is warmed. */
  enum rptadv_radio_result (*session_prepare_profiled_update)(
      const struct rptadv_radio_session *, const struct rptadv_radio_session_config *,
      const struct rptadv_radio_session_ports *, const struct rptadv_radio_profile *,
      const struct rptadv_radio_profile_capabilities *, struct rptadv_radio_session_update **);
  /** Exact-frame RX with required snapshot validity enforced. Profiled sessions
   * use this entry, not session_receive. One serial RX owner; no allocation,
   * waiting or I/O. Input is stereo; output is mono, as for session_receive. */
  enum rptadv_radio_result (*session_receive_profiled)(
      struct rptadv_radio_session *, const float *, float *, uint32_t,
      const struct rptadv_radio_profile_receive_input *,
      struct rptadv_radio_profile_receive_result *);
  /** Profiled exact-frame TX. External encode produces no native CTCSS PCM.
   * Inhibit acts live without a PTT edge. Error returns release both actions;
   * oversized spans are rejected without touching PCM. Other errors clear a
   * valid bounded PCM span. One serial TX owner; no device I/O or allocation. */
  enum rptadv_radio_result (*session_transmit_profiled)(
      struct rptadv_radio_session *, float *, uint32_t,
      const struct rptadv_radio_transmit_input *,
      struct rptadv_radio_profile_transmit_result *);
  /** Prepare shared Earshot analysis independently of a radio session.
   * Source is finite mono F32 at a fixed 8000..192000 Hz. Maximum frames
   * are 1..4096. Setup prepares storage, model state and analysis-only SRC;
   * programme PCM, source admission and manual keying belong to the caller.
   * Failure leaves a valid output handle pointer null. */
  enum rptadv_radio_result (*speech_analysis_create)(
      uint32_t source_rate_hz, uint32_t maximum_source_frames,
      struct rptadv_speech_analysis **out_analysis);
  /** Analyze a nonempty bounded source span without allocation, locks or I/O.
   * Input and sized output are valid disjoint storage; one serialized owner
   * retains the handle and library. Source discontinuity rearms analysis.
   * Complete frames use 256 analysis samples at 16 kHz; partial calls retain
   * the latest result. Hangtime and RF/phone admission are not applied here.
   * Errors clear a valid full output to inactive/zero/no last voice; a short
   * output prefix is rejected without accessing its unavailable tail. */
  enum rptadv_radio_result (*speech_analysis_process)(
      struct rptadv_speech_analysis *, const float *, uint32_t,
      uint64_t first_source_sample, struct rptadv_speech_analysis_result *);
  /** Clear classifier/converter history without allocation, retaining setup. */
  enum rptadv_radio_result (*speech_analysis_reset)(struct rptadv_speech_analysis *);
  /** Destroy a stopped uniquely owned classifier off audio; null is accepted. */
  void (*speech_analysis_destroy)(struct rptadv_speech_analysis *);
  /** Prepare independent per-source threshold/consecutive-frame qualification.
   * Existing create retains threshold 0.5 and one frame. Count only completed
   * 256-sample 16-kHz frames; partial calls do not advance onset. A score below
   * threshold, reset or discontinuity clears the streak. Caller retains sole
   * ownership of programme pre-roll/hang, sized for its configured onset delay.
   * Configuration and output storage must be valid and disjoint.
   * Invalid setup leaves a valid output handle pointer null. */
  enum rptadv_radio_result (*speech_analysis_create_configured)(
      const struct rptadv_speech_analysis_config *,
      struct rptadv_speech_analysis **out_analysis);
};

/** @brief Required readable prefix for optional shared speech-analysis operations. */
#define RPTADV_RADIO_DESCRIPTOR_SPEECH_ANALYSIS_MIN_SIZE \
  (offsetof(struct rptadv_radio_descriptor, speech_analysis_destroy) + \
   sizeof(((struct rptadv_radio_descriptor *)0)->speech_analysis_destroy))

/** @brief Required prefix for per-source speech configuration. */
#define RPTADV_RADIO_DESCRIPTOR_CONFIGURED_SPEECH_MIN_SIZE \
  (offsetof(struct rptadv_radio_descriptor, speech_analysis_create_configured) + \
   sizeof(((struct rptadv_radio_descriptor *)0)->speech_analysis_create_configured))

/**
 * @brief Return the process-lifetime ABI 5 descriptor.
 *
 * Validate `abi_version` and `struct_size` before use. ABI 2 granular
 * operations were removed rather than retained as compatibility slots.
 */
const struct rptadv_radio_descriptor *rptadv_radio_descriptor(void);

#ifdef __cplusplus
}
#endif
#endif
